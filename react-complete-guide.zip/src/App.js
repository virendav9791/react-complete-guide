import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person';

class App extends Component {
  state = {
    persons:[
      {name:"Viren", age:26},
      {name:"Hiren", age:27}
    ],
    showPerson: false
  }
  switchNameHandler = (newName) => {
    console.log('Method called');
    this.setState({
      persons:[
        {name:newName, age:29},
        {name:"Anish", age:27}
      ]
    });
  }

  nameChangeHandler = (event) => {
    console.log('Method called');
    this.setState({
      persons:[
        {name:event.target.value, age:29},
        {name:"Anish", age:27}
      ]
    });
  }

  togglePersonHandler = () => {
    const deosShow = this.state.showPerson;
    this.setState({showPerson: !deosShow});
  }

  render() {
    let person = null;

    if(this.state.showPerson){
      person = (
        <div>
          {this.state.persons.map(person =>{
            return <Person name={person.name} age={person.age} />
          })}
          <Person 
            click={this.switchNameHandler.bind(this, 'Jignesh')} 
            name={this.state.persons[0].name} 
            age={this.state.persons[0].age} 
            changed={this.nameChangeHandler}
          >My Hobbies: Movies, Masti and Magic</Person>
        </div>
      );
    }

    return (
      <div className="App">
        <h1>Hi I'm React App</h1>
        <button onClick={this.switchNameHandler.bind(this, 'Anish')}>Switch Name </button>
        <button onClick={this.togglePersonHandler}>Toggle </button>
        {person}
      </div>
    );
  }
}

export default App;
