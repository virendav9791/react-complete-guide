import React from 'react';

const person = (props) => {
    return (
        <div>
            <p>I am a {props.name} and I am {props.age} year old </p>
            <p onClick={props.click}>{props.children}</p>
            <input type="text" onChange={props.changed} />
        </div>
    )
    
}

export default person;